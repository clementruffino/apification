package apification.apification;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.json.*;
public class CreateTemplate {
    /*public static void main(String args[]) throws Exception {
        VelocityEngine ve = new VelocityEngine();
        ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "class,file");
        ve.setProperty(RuntimeConstants.RUNTIME_LOG_LOGSYSTEM_CLASS, "org.apache.velocity.runtime.log.Log4JLogChute");
        ve.setProperty("runtime.log.logsystem.log4j.logger", "VELLOGGER");
        ve.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        ve.setProperty("runtime.log.logsystem.class", "org.apache.velocity.runtime.log.NullLogSystem");
        ve.init();
        Template t = ve.getTemplate("/template/test.vm");
         
        VelocityContext vc = new VelocityContext();
            vc.put("test", "Generated");
             
        StringWriter sw = new StringWriter();
        t.merge(vc, sw);
         
        System.out.println(sw);
        
        
    }*/
	
	public static void main(String args[]) throws Exception {
		
		String envoie_tf = "provider \"tfe\" {\r\n"
				+ "  token    = \"yywVS8aWnqgtJA.atlasv1.sgJuRSWr2mCAlnWlNtcBEmp8wgw3ozY8xDjhBjFyPcrpNg3p2k5tVUGxCbSEPmJg1XM\"\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "resource \"tfe_workspace\" \"test\" {\r\n"
				+ "  name         = \"my-workspace-name\"\r\n"
				+ "  organization = \"test-apification\"\r\n"
				+ "  tag_names    = [\"test\", \"app\"]\r\n"
				+ "}\r\n"
				+ "";
		
		Api api_test = new Api("https://app.terraform.io/api/v2/","yywVS8aWnqgtJA.atlasv1.sgJuRSWr2mCAlnWlNtcBEmp8wgw3ozY8xDjhBjFyPcrpNg3p2k5tVUGxCbSEPmJg1XM", "organizations/test-apification/");
		Workspace workspace_test = new Workspace("test2");
		workspace_test.createWorkspace(api_test);
		Run test = new Run();
		test.apply(workspace_test, api_test, envoie_tf);
		TimeUnit.SECONDS.sleep(30);
		test.destroy(workspace_test, api_test, envoie_tf);
		
	}
}