package apification.apification;

import org.json.JSONObject;

public class Workspace {
	
	public String name;
	public String id;

	public Workspace(String cname) {
		name = cname;
	}

	public String getName() {
		return name;
	}

	public void setName(String pname) {
		name = pname;
	}
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String createWorkspace(Api api) throws Exception {
		String sendJSON = "{\r\n"
				+ "  \"data\": {\r\n"
				+ "    \"attributes\": {\r\n"
				+ "      \"name\": \""+ this.name + "\",\r\n"
				+ "      \"resource-count\": 0,\r\n"
				+ "      \"updated-at\": \"2017-11-29T19:18:09.976Z\",\r\n"
				+ "      \"auto-apply\": true\r\n"
				+ "    },\r\n"
				+ "    \"type\": \"workspaces\"\r\n"
				+ "  }\r\n"
				+ "}";
		
		String result = Api.sendPost(Api.getOrganization(),"workspaces", sendJSON);
		JSONObject obj = new JSONObject(result);
		String id_configuration = obj.getJSONObject("data").getString("id");
		this.setId(id_configuration);
		return result;
	}
	
	public String deleteWorkspace(Api api) throws Exception {
		return Api.sendDelete("test-apification","workspaces/"+this.name);
	}
}
