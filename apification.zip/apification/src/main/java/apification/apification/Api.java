package apification.apification;
import java.io.File;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.*;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import java.io.*;
import org.rauschig.*;
import org.rauschig.jarchivelib.ArchiveFormat;
import org.rauschig.jarchivelib.Archiver;
import org.rauschig.jarchivelib.ArchiverFactory;
import org.rauschig.jarchivelib.CompressionType;

public class Api {
	
	public static String API_URL;
	public static String Token;
	public static String Organization;
	
	public static String getOrganization() {
		return Organization;
	}


	public static void setOrganization(String organization) {
		Organization = organization;
	}


	public Api(String Api_url, String token,String organization) {
		API_URL = Api_url;
		Token = token;
		Organization = organization;
	}

	
	public String getAPI_URL() {
		return API_URL;
	}


	public void setAPI_URL(String aPI_URL) {
		API_URL = aPI_URL;
	}


	public String getToken() {
		return Token;
	}


	public void setToken(String token) {
		Token = token;
	}

	public static String sendGet(String Organization,String end_url) throws Exception {
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
			HttpUriRequest request = RequestBuilder.get()
					.setUri(API_URL + Organization + end_url)
				    .setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + Token)
				    .build();
			
			CloseableHttpResponse response = httpclient.execute(request);
			HttpEntity entity = response.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			return responseString;
		}
	}
	
	public static String sendPost(String Organization,String end_url,String body) throws Exception {
	    HttpUriRequest request = RequestBuilder.post()
			    .setUri(API_URL + Organization + end_url)
			    .setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + Token)
			    .setHeader(HttpHeaders.CONTENT_TYPE, "application/vnd.api+json")
			    .setEntity(new StringEntity(body))
			    .build();
	    
	    
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {		
			CloseableHttpResponse response = httpclient.execute(request);
			HttpEntity entity = response.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			return responseString;
		}
	}
	
	public static String sendDelete(String Organization,String end_url) throws Exception {
		
	    HttpUriRequest request = RequestBuilder.delete()
	    		.setUri(API_URL + "organizations/" + Organization + "/" + end_url)
			    .setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + Token)
			    .setHeader(HttpHeaders.CONTENT_TYPE, "application/vnd.api+json")
			    .build();
	    
	    
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {		
			CloseableHttpResponse response = httpclient.execute(request);
			HttpEntity entity = response.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			return responseString;
		}
	}
	
public static String sendPut(String Url,String body) throws Exception {
		
		File source = new File("conf");
		File destination = new File("archive_dest");
		Archiver archiver = ArchiverFactory.createArchiver(ArchiveFormat.TAR, CompressionType.GZIP);
		
		File archive = archiver.create("conf_tf", destination, source);
			
		FileEntity reqEntity = new FileEntity(archive, ContentType.APPLICATION_OCTET_STREAM);
	    @SuppressWarnings("deprecation")
		HttpUriRequest request = RequestBuilder.put()
			    .setUri(Url)
			    .setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + Token)
			    .setHeader(HttpHeaders.CONTENT_TYPE, "application/octet-stream")
			    .setEntity(reqEntity)
			    .build();

	   
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {		
			CloseableHttpResponse response = httpclient.execute(request);
			HttpEntity entity = response.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			return responseString;
		}
	}
}
