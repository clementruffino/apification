package apification.apification;

import org.json.JSONObject;

public class Run {

	String id;
	
	
	public Run() {
	}

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}

	public String apply(Workspace workspace, Api api,String filename) throws Exception {
		String sendJSON = "{\r\n"
				+ "  \"data\": {\r\n"
				+ "    \"type\": \"configuration-versions\",\r\n"
				+ "    \"attributes\": {\r\n"
				+ "      \"auto-queue-runs\": true\r\n"
				+ "    }\r\n"
				+ "  }\r\n"
				+ "}";
		
		String result = Api.sendPost("","workspaces/"+ workspace.getId() +"/configuration-versions", sendJSON);
		JSONObject obj = new JSONObject(result);
		String id_configuration = obj.getJSONObject("data").getString("id");
		String url_upload = obj.getJSONObject("data").getJSONObject("attributes").getString("upload-url");
		
		return Api.sendPut(url_upload,filename);

	}
	
	public String destroy(Workspace workspace, Api api,String filename) throws Exception {
		String sendJSON = "{\r\n"
				+ "  \"data\": {\r\n"
				+ "    \"type\": \"configuration-versions\",\r\n"
				+ "    \"attributes\": {\r\n"
				+ "      \"auto-queue-runs\": true\r\n"
				+ "    }\r\n"
				+ "  }\r\n"
				+ "}";
		String result = api.sendPost("test-apification","workspaces/"+ workspace.getId() +"/configuration-versions", sendJSON);
		JSONObject obj = new JSONObject(result);
		String id_configuration = obj.getJSONObject("data").getString("id");
		String url_upload = obj.getJSONObject("data").getJSONObject("attributes").getString("upload-url");
		api.sendPut(url_upload,filename);
		
		
		String payload = "{\r\n"
				+ "  \"data\": {\r\n"
				+ "    \"attributes\": {\r\n"
				+ "      \"message\": \"Generated\"\r\n"
				+ "       \"is-destroy\": \"true\"\r\n"
				+ "    },\r\n"
				+ "    \"type\":\"runs\",\r\n"
				+ "    \"relationships\": {\r\n"
				+ "      \"workspace\": {\r\n"
				+ "        \"data\": {\r\n"
				+ "          \"type\": \"workspaces\",\r\n"
				+ "          \"id\": \""+workspace.getId()+"\"\r\n"
				+ "        }\r\n"
				+ "      },\r\n"
				+ "      \"configuration-version\": {\r\n"
				+ "        \"data\": {\r\n"
				+ "          \"type\": \"configuration-versions\",\r\n"
				+ "          \"id\": \""+id_configuration+"\"\r\n"
				+ "        }\r\n"
				+ "      }\r\n"
				+ "    }\r\n"
				+ "  }\r\n"
				+ "}";
		
		String result_run = api.sendPost("","runs",payload);
		JSONObject json_run = new JSONObject(result_run);
		String id_run = json_run.getJSONObject("data").getString("id");
		String final_result = api.sendPost("","runs/"+id_run+"/actions/apply","Generated");
		return final_result;
	}
}
